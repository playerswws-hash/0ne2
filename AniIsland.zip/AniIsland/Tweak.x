#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <math.h>

// ---------- Настройки внешнего вида ----------
#define PILL_Y        36.0   // отступ сверху (ниже выреза iPhone 11)
#define PILL_W        270.0  // ширина раскрытого острова
#define PILL_H        46.0   // высота раскрытого острова
#define SHOW_SECONDS  4.0    // сколько секунд остров открыт

typedef void (*MRGetInfoFunc)(dispatch_queue_t, void (^)(CFDictionaryRef));
typedef void (*MRRegisterFunc)(dispatch_queue_t);
static MRGetInfoFunc gGetInfo = NULL;

// Окно, пропускающее касания сквозь себя
@interface ATPassWindow : UIWindow
@end
@implementation ATPassWindow
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *v = [super hitTest:p withEvent:e];
    if (v == self || v == self.rootViewController.view) return nil;
    return v;
}
@end

@interface ATIsland : NSObject
@property (nonatomic, strong) ATPassWindow *window;
@property (nonatomic, strong) UIView *pill;
@property (nonatomic, strong) UIImageView *icon;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) NSTimer *hideTimer;
@property (nonatomic, copy) NSString *lastTrack;
@property (nonatomic, assign) BOOL started;
+ (instancetype)shared;
- (void)start;
- (void)showIcon:(UIImage *)icon text:(NSString *)text tint:(UIColor *)tint round:(BOOL)round;
@end

@implementation ATIsland

+ (instancetype)shared {
    static ATIsland *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [ATIsland new]; });
    return s;
}

- (CGRect)collapsedFrame {
    CGFloat W = UIScreen.mainScreen.bounds.size.width;
    return CGRectMake((W - 60) / 2, PILL_Y + 8, 60, PILL_H - 16);
}
- (CGRect)expandedFrame {
    CGFloat W = UIScreen.mainScreen.bounds.size.width;
    return CGRectMake((W - PILL_W) / 2, PILL_Y, PILL_W, PILL_H);
}

- (void)buildWindow {
    if (self.window) return;

    UIWindowScene *scene = nil;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if ([s isKindOfClass:[UIWindowScene class]]) { scene = (UIWindowScene *)s; break; }
    }
    CGRect bounds = UIScreen.mainScreen.bounds;
    ATPassWindow *w = scene ? [[ATPassWindow alloc] initWithWindowScene:scene]
                            : [[ATPassWindow alloc] initWithFrame:bounds];
    w.frame = bounds;
    w.windowLevel = UIWindowLevelAlert + 1000;
    w.backgroundColor = UIColor.clearColor;

    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = UIColor.clearColor;
    w.rootViewController = vc;

    UIView *pill = [[UIView alloc] initWithFrame:[self collapsedFrame]];
    pill.backgroundColor = UIColor.blackColor;
    pill.layer.cornerRadius = (PILL_H - 16) / 2;
    pill.clipsToBounds = YES;
    pill.alpha = 0;

    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(9, 7, 32, 32)];
    icon.contentMode = UIViewContentModeScaleAspectFill;
    icon.clipsToBounds = YES;

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, PILL_W - 62, PILL_H)];
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.7;

    [pill addSubview:icon];
    [pill addSubview:label];
    [vc.view addSubview:pill];

    w.hidden = NO;
    self.window = w; self.pill = pill; self.icon = icon; self.label = label;
}

- (void)showIcon:(UIImage *)icon text:(NSString *)text tint:(UIColor *)tint round:(BOOL)round {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self buildWindow];
        self.icon.image = icon;
        self.icon.tintColor = tint;
        self.icon.layer.cornerRadius = round ? 16 : 7;
        self.label.text = text;

        [self.hideTimer invalidate];
        [UIView animateWithDuration:0.5 delay:0 usingSpringWithDamping:0.7
              initialSpringVelocity:0.8 options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
            self.pill.frame = [self expandedFrame];
            self.pill.layer.cornerRadius = PILL_H / 2;
            self.pill.alpha = 1;
        } completion:nil];

        self.hideTimer = [NSTimer scheduledTimerWithTimeInterval:SHOW_SECONDS repeats:NO
                                                           block:^(NSTimer *t) {
            [UIView animateWithDuration:0.35 delay:0 options:UIViewAnimationOptionBeginFromCurrentState
                             animations:^{
                self.pill.frame = [self collapsedFrame];
                self.pill.layer.cornerRadius = (PILL_H - 16) / 2;
                self.pill.alpha = 0;
            } completion:nil];
        }];
    });
}

- (void)refreshMusic {
    if (!gGetInfo) return;
    gGetInfo(dispatch_get_main_queue(), ^(CFDictionaryRef cf) {
        NSDictionary *info = (__bridge NSDictionary *)cf;
        NSString *title = info[@"kMRMediaRemoteNowPlayingInfoTitle"];
        NSString *artist = info[@"kMRMediaRemoteNowPlayingInfoArtist"];
        NSData *art = info[@"kMRMediaRemoteNowPlayingInfoArtworkData"];
        if (![title isKindOfClass:[NSString class]] || title.length == 0) return;
        if ([title isEqualToString:self.lastTrack]) return;
        self.lastTrack = title;

        UIImage *img = ([art isKindOfClass:[NSData class]] ? [UIImage imageWithData:art] : nil);
        BOOL hasArt = (img != nil);
        if (!img) img = [[UIImage systemImageNamed:@"music.note"]
                         imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        NSString *text = ([artist isKindOfClass:[NSString class]] && artist.length)
            ? [NSString stringWithFormat:@"%@ — %@", title, artist] : title;
        [self showIcon:img text:text tint:UIColor.whiteColor round:!hasArt];
    });
}

- (void)start {
    if (self.started) return;
    self.started = YES;
    [self buildWindow];

    // Сообщение при запуске, чтобы сразу было видно, что остров работает
    UIImage *ok = [[UIImage systemImageNamed:@"checkmark.circle.fill"]
                   imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [self showIcon:ok text:@"AniIsland готов" tint:UIColor.systemGreenColor round:YES];

    // Зарядка
    UIDevice.currentDevice.batteryMonitoringEnabled = YES;
    [[NSNotificationCenter defaultCenter]
        addObserverForName:UIDeviceBatteryStateDidChangeNotification object:nil
                     queue:NSOperationQueue.mainQueue
                usingBlock:^(NSNotification *n) {
        UIDeviceBatteryState st = UIDevice.currentDevice.batteryState;
        if (st != UIDeviceBatteryStateCharging && st != UIDeviceBatteryStateFull) return;
        int pct = (int)roundf(UIDevice.currentDevice.batteryLevel * 100);
        UIImage *bolt = [[UIImage systemImageNamed:@"bolt.fill"]
                         imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [self showIcon:bolt
                  text:[NSString stringWithFormat:@"Зарядка  %d%%", pct]
                  tint:UIColor.systemGreenColor round:YES];
    }];

    // Музыка (MediaRemote)
    void *h = dlopen("/System/Library/PrivateFrameworks/MediaRemote.framework/MediaRemote", RTLD_LAZY);
    if (h) {
        MRRegisterFunc reg = (MRRegisterFunc)dlsym(h, "MRMediaRemoteRegisterForNowPlayingNotifications");
        gGetInfo = (MRGetInfoFunc)dlsym(h, "MRMediaRemoteGetNowPlayingInfo");
        if (reg) reg(dispatch_get_main_queue());
        [[NSNotificationCenter defaultCenter]
            addObserverForName:@"kMRMediaRemoteNowPlayingInfoDidChangeNotification" object:nil
                         queue:NSOperationQueue.mainQueue
                    usingBlock:^(NSNotification *n) { [self refreshMusic]; }];
    }
}
@end

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[ATIsland shared] start];
    });
}
%end
