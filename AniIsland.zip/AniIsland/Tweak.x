#import <UIKit/UIKit.h>
#import <dlfcn.h>
#import <math.h>

// ---------- Настройки ----------
#define NOTCH_H       30.0   // высота выреза iPhone 11
#define ZONE_W        120.0  // ширина зоны нажатия под вырезом
#define ZONE_H        22.0   // высота зоны нажатия
#define ZONE_GAP      2.0    // отступ зоны от нижнего края выреза
#define DEBUG_ZONE    1      // 1 = зона подсвечена тонкой рамкой, 0 = невидима
#define PILL_TOP      36.0   // верх острова (от верха экрана), ниже выреза
#define PILL_W        300.0  // ширина острова с кнопками
#define MUSIC_H       108.0  // высота острова с кнопками
#define INFO_W        250.0  // ширина маленького острова (зарядка и т.п.)
#define INFO_H        60.0   // высота маленького острова
#define SHOW_SECONDS  8.0    // сколько секунд остров открыт (касание продлевает)

// Коды команд MediaRemote (закрытое API)
#define CMD_TOGGLE    2
#define CMD_NEXT      4
#define CMD_PREV      5

typedef void (*MRGetInfoFunc)(dispatch_queue_t, void (^)(CFDictionaryRef));
typedef void (*MRRegisterFunc)(dispatch_queue_t);
typedef Boolean (*MRSendFunc)(unsigned int, id);
typedef void (*MRIsPlayingFunc)(dispatch_queue_t, void (^)(Boolean));
static MRGetInfoFunc gGetInfo = NULL;
static MRSendFunc gSend = NULL;
static MRIsPlayingFunc gIsPlaying = NULL;

// Окно, пропускающее касания сквозь себя
@interface ATPassWindow : UIWindow
@end
@implementation ATPassWindow
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *v = [super hitTest:p withEvent:e];
    if (v == self || v == self.rootViewController.view) return nil;
    return v;
}
@end

@interface ATIsland : NSObject
@property (nonatomic, strong) ATPassWindow *window;
@property (nonatomic, strong) UIView *zone;
@property (nonatomic, strong) UIView *pill;
@property (nonatomic, strong) UIImageView *icon;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *artistLabel;
@property (nonatomic, strong) UIButton *prevBtn;
@property (nonatomic, strong) UIButton *playBtn;
@property (nonatomic, strong) UIButton *nextBtn;
@property (nonatomic, strong) NSTimer *hideTimer;
@property (nonatomic, copy) NSString *lastTrack;
@property (nonatomic, assign) BOOL started;
@property (nonatomic, assign) BOOL forceNext;
@property (nonatomic, assign) BOOL shown;
@property (nonatomic, assign) BOOL musicMode;
@property (nonatomic, assign) BOOL playing;
+ (instancetype)shared;
- (void)start;
@end

@implementation ATIsland

+ (instancetype)shared {
    static ATIsland *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [ATIsland new]; });
    return s;
}

// ---------- Геометрия ----------
- (CGFloat)screenW { return UIScreen.mainScreen.bounds.size.width; }
- (CGRect)zoneFrame {
    return CGRectMake(([self screenW] - ZONE_W) / 2, NOTCH_H + ZONE_GAP, ZONE_W, ZONE_H);
}
- (CGRect)hiddenFrame {
    return CGRectMake(([self screenW] - ZONE_W) / 2, NOTCH_H, ZONE_W, 20);
}
- (CGRect)musicFrame {
    return CGRectMake(([self screenW] - PILL_W) / 2, PILL_TOP, PILL_W, MUSIC_H);
}
- (CGRect)infoFrame {
    return CGRectMake(([self screenW] - INFO_W) / 2, PILL_TOP, INFO_W, INFO_H);
}

// ---------- Построение интерфейса ----------
- (UIButton *)makeButton:(NSString *)sym action:(SEL)sel x:(CGFloat)x {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.frame = CGRectMake(x, 62, 64, 40);
    b.tintColor = UIColor.whiteColor;
    [self setSymbol:sym onButton:b];
    [b addTarget:self action:sel forControlEvents:UIControlEventTouchUpInside];
    return b;
}

- (void)setSymbol:(NSString *)sym onButton:(UIButton *)b {
    UIImageSymbolConfiguration *cfg =
        [UIImageSymbolConfiguration configurationWithPointSize:24 weight:UIImageSymbolWeightMedium];
    UIImage *img = [[UIImage systemImageNamed:sym withConfiguration:cfg]
                    imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [b setImage:img forState:UIControlStateNormal];
}

- (void)buildWindow {
    if (self.window) return;

    UIWindowScene *scene = nil;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if ([s isKindOfClass:[UIWindowScene class]]) { scene = (UIWindowScene *)s; break; }
    }
    CGRect bounds = UIScreen.mainScreen.bounds;
    ATPassWindow *w = scene ? [[ATPassWindow alloc] initWithWindowScene:scene]
                            : [[ATPassWindow alloc] initWithFrame:bounds];
    w.frame = bounds;
    w.windowLevel = UIWindowLevelAlert + 1000;
    w.backgroundColor = UIColor.clearColor;

    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = UIColor.clearColor;
    w.rootViewController = vc;

    // Зона нажатия под вырезом
    UIView *zone = [[UIView alloc] initWithFrame:[self zoneFrame]];
    zone.backgroundColor = UIColor.clearColor;
    if (DEBUG_ZONE) {
        zone.backgroundColor = [UIColor colorWithWhite:1 alpha:0.10];
        zone.layer.borderWidth = 0.5;
        zone.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.5].CGColor;
        zone.layer.cornerRadius = 8;
    }
    [zone addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(zoneTapped)]];
    [vc.view addSubview:zone];

    // Сам остров (скрыт, пока не вызван)
    UIView *pill = [[UIView alloc] initWithFrame:[self hiddenFrame]];
    pill.backgroundColor = UIColor.blackColor;
    pill.clipsToBounds = YES;
    pill.layer.cornerRadius = 12;
    pill.alpha = 0;
    pill.hidden = YES;

    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 12, 48, 48)];
    icon.clipsToBounds = YES;

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(72, 12, 214, 22)];
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    title.adjustsFontSizeToFitWidth = YES;
    title.minimumScaleFactor = 0.8;

    UILabel *artist = [[UILabel alloc] initWithFrame:CGRectMake(72, 34, 214, 18)];
    artist.textColor = [UIColor colorWithWhite:1 alpha:0.6];
    artist.font = [UIFont systemFontOfSize:13];

    UIButton *prev = [self makeButton:@"backward.fill" action:@selector(prevTapped) x:43];
    UIButton *play = [self makeButton:@"pause.fill" action:@selector(playTapped) x:118];
    UIButton *next = [self makeButton:@"forward.fill" action:@selector(nextTapped) x:193];

    [pill addSubview:icon];
    [pill addSubview:title];
    [pill addSubview:artist];
    [pill addSubview:prev];
    [pill addSubview:play];
    [pill addSubview:next];

    // Касание острова продлевает показ, свайп вверх закрывает
    [pill addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(restartTimer)]];
    UISwipeGestureRecognizer *sw = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(hideNow)];
    sw.direction = UISwipeGestureRecognizerDirectionUp;
    [pill addGestureRecognizer:sw];

    [vc.view addSubview:pill];

    w.hidden = NO;
    self.window = w; self.zone = zone; self.pill = pill; self.icon = icon;
    self.titleLabel = title; self.artistLabel = artist;
    self.prevBtn = prev; self.playBtn = play; self.nextBtn = next;
    self.playing = YES;
}

- (void)layoutContent {
    BOOL m = self.musicMode;
    if (m) {
        self.icon.frame = CGRectMake(14, 12, 48, 48);
        self.titleLabel.frame = CGRectMake(72, 12, PILL_W - 86, 22);
        self.artistLabel.frame = CGRectMake(72, 34, PILL_W - 86, 18);
    } else {
        self.icon.frame = CGRectMake(14, 12, 36, 36);
        self.titleLabel.frame = CGRectMake(60, 12, INFO_W - 74, 36);
    }
    self.artistLabel.hidden = !m;
    self.prevBtn.hidden = !m;
    self.playBtn.hidden = !m;
    self.nextBtn.hidden = !m;
}

// ---------- Показ / скрытие ----------
- (void)present {
    BOOL music = self.musicMode;
    [self layoutContent];
    BOOL wasHidden = self.pill.hidden;
    if (wasHidden) {
        self.pill.frame = [self hiddenFrame];
        self.pill.alpha = 0;
        self.pill.layer.cornerRadius = 12;
    }
    self.pill.hidden = NO;
    self.shown = YES;

    [UIView animateWithDuration:0.5 delay:0 usingSpringWithDamping:0.75
          initialSpringVelocity:0.8 options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
        self.pill.frame = music ? [self musicFrame] : [self infoFrame];
        self.pill.alpha = 1;
        self.pill.layer.cornerRadius = music ? 28 : 24;
    } completion:nil];
    [self restartTimer];
}

- (void)restartTimer {
    if (!self.shown) return;
    [self.hideTimer invalidate];
    self.hideTimer = [NSTimer scheduledTimerWithTimeInterval:SHOW_SECONDS repeats:NO
                                                       block:^(NSTimer *t) { [self hideNow]; }];
}

- (void)hideNow {
    [self.hideTimer invalidate];
    self.hideTimer = nil;
    if (!self.shown) return;
    self.shown = NO;
    [UIView animateWithDuration:0.35 delay:0 options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
        self.pill.frame = [self hiddenFrame];
        self.pill.alpha = 0;
        self.pill.layer.cornerRadius = 12;
    } completion:^(BOOL f) {
        if (!self.shown) self.pill.hidden = YES;
    }];
}

// Маленький остров: зарядка, сообщения
- (void)showInfoIcon:(UIImage *)icon text:(NSString *)text tint:(UIColor *)tint {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self buildWindow];
        self.musicMode = NO;
        self.icon.contentMode = UIViewContentModeScaleAspectFit;
        self.icon.layer.cornerRadius = 0;
        self.icon.tintColor = tint;
        self.icon.image = icon;
        self.titleLabel.text = text;
        [self present];
    });
}

// Остров с треком и кнопками
- (void)showTrack:(UIImage *)img hasArt:(BOOL)hasArt title:(NSString *)title artist:(NSString *)artist {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self buildWindow];
        self.musicMode = YES;
        self.icon.contentMode = hasArt ? UIViewContentModeScaleAspectFill : UIViewContentModeScaleAspectFit;
        self.icon.layer.cornerRadius = hasArt ? 8 : 0;
        self.icon.tintColor = UIColor.whiteColor;
        self.icon.image = img;
        self.titleLabel.text = title;
        self.artistLabel.text = artist ?: @"";
        [self present];
        [self syncPlayState];
    });
}

// ---------- Кнопки ----------
- (void)setPlayingIcon:(BOOL)playing {
    self.playing = playing;
    [self setSymbol:(playing ? @"pause.fill" : @"play.fill") onButton:self.playBtn];
}

- (void)syncPlayState {
    if (!gIsPlaying) return;
    gIsPlaying(dispatch_get_main_queue(), ^(Boolean p) { [self setPlayingIcon:p]; });
}

- (void)sendCmd:(unsigned int)c {
    if (gSend) gSend(c, nil);
    [self restartTimer];
}
- (void)prevTapped { [self sendCmd:CMD_PREV]; }
- (void)nextTapped { [self sendCmd:CMD_NEXT]; }
- (void)playTapped {
    [self sendCmd:CMD_TOGGLE];
    [self setPlayingIcon:!self.playing];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ [self syncPlayState]; });
}

// Тап по зоне под вырезом
- (void)zoneTapped {
    self.lastTrack = nil;
    self.forceNext = YES;
    [self refreshMusic];
}

// ---------- Музыка ----------
- (void)refreshMusic {
    if (!gGetInfo) return;
    gGetInfo(dispatch_get_main_queue(), ^(CFDictionaryRef cf) {
        NSDictionary *info = (__bridge NSDictionary *)cf;
        NSString *title = info[@"kMRMediaRemoteNowPlayingInfoTitle"];
        NSString *artist = info[@"kMRMediaRemoteNowPlayingInfoArtist"];
        NSData *art = info[@"kMRMediaRemoteNowPlayingInfoArtworkData"];
        NSNumber *rate = info[@"kMRMediaRemoteNowPlayingInfoPlaybackRate"];
        BOOL force = self.forceNext;
        self.forceNext = NO;

        if (![title isKindOfClass:[NSString class]] || title.length == 0) {
            if (force) {
                UIImage *n = [[UIImage systemImageNamed:@"music.note.slash"]
                              imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
                [self showInfoIcon:n text:@"Ничего не играет" tint:UIColor.whiteColor];
            }
            return;
        }
        if (self.playBtn && [rate isKindOfClass:[NSNumber class]]) {
            [self setPlayingIcon:(rate.floatValue > 0.01)];
        }
        if ([title isEqualToString:self.lastTrack]) return;
        self.lastTrack = title;

        UIImage *img = ([art isKindOfClass:[NSData class]] ? [UIImage imageWithData:art] : nil);
        BOOL hasArt = (img != nil);
        if (!img) img = [[UIImage systemImageNamed:@"music.note"]
                         imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        NSString *a = [artist isKindOfClass:[NSString class]] ? artist : @"";
        [self showTrack:img hasArt:hasArt title:title artist:a];
    });
}

// ---------- Запуск ----------
- (void)start {
    if (self.started) return;
    self.started = YES;
    [self buildWindow];

    // Сообщение при запуске, чтобы сразу было видно, что остров работает
    UIImage *ok = [[UIImage systemImageNamed:@"checkmark.circle.fill"]
                   imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [self showInfoIcon:ok text:@"AniIsland 0.3 готов" tint:UIColor.systemGreenColor];

    // Зарядка
    UIDevice.currentDevice.batteryMonitoringEnabled = YES;
    [[NSNotificationCenter defaultCenter]
        addObserverForName:UIDeviceBatteryStateDidChangeNotification object:nil
                     queue:NSOperationQueue.mainQueue
                usingBlock:^(NSNotification *n) {
        UIDeviceBatteryState st = UIDevice.currentDevice.batteryState;
        if (st != UIDeviceBatteryStateCharging && st != UIDeviceBatteryStateFull) return;
        int pct = (int)roundf(UIDevice.currentDevice.batteryLevel * 100);
        UIImage *bolt = [[UIImage systemImageNamed:@"bolt.fill"]
                         imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [self showInfoIcon:bolt
                      text:[NSString stringWithFormat:@"Зарядка  %d%%", pct]
                      tint:UIColor.systemGreenColor];
    }];

    // Музыка (MediaRemote)
    void *h = dlopen("/System/Library/PrivateFrameworks/MediaRemote.framework/MediaRemote", RTLD_LAZY);
    if (h) {
        MRRegisterFunc reg = (MRRegisterFunc)dlsym(h, "MRMediaRemoteRegisterForNowPlayingNotifications");
        gGetInfo = (MRGetInfoFunc)dlsym(h, "MRMediaRemoteGetNowPlayingInfo");
        gSend = (MRSendFunc)dlsym(h, "MRMediaRemoteSendCommand");
        gIsPlaying = (MRIsPlayingFunc)dlsym(h, "MRMediaRemoteGetNowPlayingApplicationIsPlaying");
        if (reg) reg(dispatch_get_main_queue());
        [[NSNotificationCenter defaultCenter]
            addObserverForName:@"kMRMediaRemoteNowPlayingInfoDidChangeNotification" object:nil
                         queue:NSOperationQueue.mainQueue
                    usingBlock:^(NSNotification *n) { [self refreshMusic]; }];
        [[NSNotificationCenter defaultCenter]
            addObserverForName:@"kMRMediaRemoteNowPlayingApplicationIsPlayingDidChangeNotification" object:nil
                         queue:NSOperationQueue.mainQueue
                    usingBlock:^(NSNotification *n) { [self syncPlayState]; }];
    }
}
@end

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[ATIsland shared] start];
    });
}
%end
